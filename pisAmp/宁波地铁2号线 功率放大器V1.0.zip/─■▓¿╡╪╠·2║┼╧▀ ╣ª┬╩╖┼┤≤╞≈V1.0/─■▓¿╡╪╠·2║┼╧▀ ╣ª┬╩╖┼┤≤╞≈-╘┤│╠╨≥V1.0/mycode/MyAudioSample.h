//*******************************************************//
//						MyAudioSample.h								//
//*******************************************************//

#ifndef _MYAUDIOSAMPLE_H
#define  _MYAUDIOSAMPLE_H

#include "MyAll.h"




extern const uint16_t Sin100Sample[441];

extern const uint16_t Sin200Sample[441];

extern const uint16_t Sin500Sample[441];

extern const uint16_t Sin800Sample[441];

extern const uint16_t Sin1kSample[441];

extern const uint16_t Sin2kSample[441];

extern const uint16_t Sin5kSample[441];

extern const uint16_t Sin8kSample[441];

extern const uint16_t Sin10kSample[441];

extern const uint16_t Sin15kSample[441];

extern const uint16_t Sin20kSample[441];






#endif


