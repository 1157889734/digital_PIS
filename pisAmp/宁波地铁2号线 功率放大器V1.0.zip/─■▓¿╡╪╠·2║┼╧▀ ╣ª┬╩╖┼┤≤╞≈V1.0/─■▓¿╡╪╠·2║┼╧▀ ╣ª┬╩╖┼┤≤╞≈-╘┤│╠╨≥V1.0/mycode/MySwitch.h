//*******************************************************//
//						MySwitch.h								//
//*******************************************************//

#ifndef _MYSWITCH_H
#define  _MYSWITCH_H

#include "MyAll.h"






void SwitchInit(void);



#endif


